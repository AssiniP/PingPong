# PingPong
Aplicación web de preguntas y respuestas basada en el patrón de diseño MVC.
# Características
- Hecho en PHP.
- Intregración con bases de datos MariaDB.
- Diversión!
# Créditos
Creada por el grupo 10 (UmbrellaCorp).
UNLam 2023.
