<?php
include_once 'ApiPreguntas.php';

$api = new ApiPreguntas();

$api->getAll();
